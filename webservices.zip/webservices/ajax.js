function getMovies(){
	console.log("get operation");
	var xhttp=new XMLHttpRequest();
	xhttp.onreadystatechange=function(){
		if(this.readyState == 4 && this.status == 200){
			console.log(this.responseText);
		}
	}
	xhttp.open("GET","http://localhost:8080/Rest_One/getmovies");
	xhttp.send();
	
	
}

   function loadDoc(){
				var movieName=document.getElementById("movieName").value;
				
			var xhttp=new XMLHttpRequest();
			xhttp.onreadystatechange=function(){
				if(this.readyState == 4 && this.status ==200){
				console.log(this.responseText);
				
                    var result=JSON.parse(this.responseText).results;
                    document.getElementById("title").innerHTML=result[0].title;
                    document.getElementById("original_language").innerHTML=result[0].original_language;
                    document.getElementById("overview").innerHTML=result[0].overview;
					//document.getElementById("result").innerHTML=JSON.stringify(result);
				}
			}
			
			 xhttp.open("GET", "https://api.themoviedb.org/3/search/movie?api_key=4f5cce9a7fbf2e48594e07499df40a5d&query="+movieName, true);
			  xhttp.send();
			}

   