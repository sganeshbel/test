package com.xworkz.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.xworkz.restapi.entity.Movie;
import com.xworkz.restapi.repository.MovieRepository;

@Service
public class MovieService {

	@Autowired
	private MovieRepository movieRepository;

	public void addMovie(Movie movie) {
		System.out.println("movie {} inside MovieService" + movie);
		movieRepository.addMovie(movie);
	}

	public void addMovies(List<Movie> movieList) {
		movieRepository.addMovies(movieList);
	}

	public List<Movie> getMovies() {
		return movieRepository.getMovies();
	}

	public Movie getMovieById(Long id) {
		return movieRepository.getMovieById(id);
	}

	public void deleteMovieById(Long id) {
		movieRepository.deleteMovieById(id);
	}

	public void updateMovie(Movie updatedMovie) {
		movieRepository.updateMovie(updatedMovie);
	}
}
