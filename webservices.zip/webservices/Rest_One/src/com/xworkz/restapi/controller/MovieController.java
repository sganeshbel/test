package com.xworkz.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.xworkz.restapi.entity.Movie;
import com.xworkz.restapi.service.MovieService;

@RestController
@CrossOrigin("*")
public class MovieController {
	
	@Autowired
	private MovieService movieService;
	
	//@RequestMapping(value="/addmovie",method=RequestMethod.POST)
	@PostMapping(value="/addmovie")
	public void addMovie(@RequestBody Movie movie) {
		System.out.println("movie {} inside MovieController"+ movie);
		movieService.addMovie(movie);
	}
	
	@PostMapping(value="/addmovies")
	public void addMovies(@RequestBody List<Movie> movieList) {
		movieService.addMovies(movieList);
	}
	
	@GetMapping(value="/getmovies")
	public List<Movie> getMovies() {
		return movieService.getMovies();
	}
	@GetMapping(value="/getmovie/{id}")
	public Movie getMovieById(@PathVariable("id") Long id) {
		return movieService.getMovieById(id);
	}
	@DeleteMapping(value="/deletemovie/{id}")
	public void deleteMovieById(@PathVariable("id")Long id) {
		movieService.deleteMovieById(id);
	}
	
	@PutMapping(value="/updatemovie")
	public void updateMovie(@RequestBody Movie updatedMovie) {
		System.err.println(updatedMovie);
		movieService.updateMovie(updatedMovie);
	}
	
	@GetMapping(value="/getJsonplaceholderapidata")
	public void getDataFromJsopPlaceHolderApi() {
		RestTemplate restEmplate=new RestTemplate();
		String fromJsonApi=	restEmplate.getForObject
				("https://jsonplaceholder.typicode.com/todos/1", String.class);
		System.out.println(fromJsonApi);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
