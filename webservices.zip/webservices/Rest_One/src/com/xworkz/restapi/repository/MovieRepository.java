package com.xworkz.restapi.repository;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.xworkz.restapi.entity.Movie;

@Repository
public class MovieRepository {

	@Autowired
	private SessionFactory sessionFactory;

	public void addMovie(Movie movie) {
		System.out.println("movie {} inside MovieService" + movie);
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(movie);
			transaction.commit();
		} catch (HibernateException he) {
			he.printStackTrace();
		} finally {
			session.close();
		}

	}

	public void addMovies(List<Movie> movieList) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {

			movieList.forEach(a -> {
				session.save(a);

			});
			transaction.commit();

		} catch (HibernateException he) {
			he.printStackTrace();
		} finally {
			session.close();
		}

	}

	public List<Movie> getMovies() {

		Session session = sessionFactory.openSession();
		String hqlQuery = "from Movie";
		Query query = session.createQuery(hqlQuery);
		try {
			return query.list();
		} catch (HibernateException he) {
			he.printStackTrace();
		} finally {
			session.close();
		}
		return Collections.emptyList();
	}

	public Movie getMovieById(Long id) {
		Session session = sessionFactory.openSession();
		String hqlQuery = "from Movie where id=:idfromuser";
		Query query = session.createQuery(hqlQuery);
		query.setParameter("idfromuser", id);
		return (Movie) query.uniqueResult();
	}

	public void deleteMovieById(Long id) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hqlQuery = "delete Movie where id=:idfromuser";
		Query query = session.createQuery(hqlQuery);
		query.setParameter("idfromuser", id);
		query.executeUpdate();
		transaction.commit();
	}

	public void updateMovie(Movie updatedMovie) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(updatedMovie);
		//session.merge(updatedMovie)
		transaction.commit();
	}

}
