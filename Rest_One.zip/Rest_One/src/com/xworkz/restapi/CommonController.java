package com.xworkz.restapi;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
//@ResponseBody
@RestController
public class CommonController {

	public CommonController() {
		System.out.println(this.getClass().getSimpleName() + "created");
	}

	@RequestMapping(value="/getMovies")
	public List<MovieDto> getMovies() {
		
	List<MovieDto>listOfMovies=new ArrayList<MovieDto>();
	
			MovieDto mdto1=new MovieDto();
			mdto1.setId(new Long(1));
			mdto1.setName("URI");
			mdto1.setLanguage("Hindi");
			mdto1.setRatings(5.0);
			
			listOfMovies.add(mdto1);
			MovieDto mdto2=new MovieDto();
			mdto2.setId(new Long(2));
			mdto2.setName("KadiPudi");
			mdto2.setLanguage("Kannada");
			mdto2.setRatings(4.0);
			
			listOfMovies.add(mdto2);
			
			return listOfMovies;
			
	}
	
	
	@RequestMapping(value = "/get")
	public String getData() {
		return "String";
	}

}
